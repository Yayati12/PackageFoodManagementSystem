import { Check, Package, ChevronRight } from 'lucide-react';
import { Order } from '../types';
import { Button } from './ui/button';
import { motion } from 'motion/react';

interface OrderConfirmationProps {
  order: Order;
  onTrackOrder: () => void;
}

export function OrderConfirmation({ order, onTrackOrder }: OrderConfirmationProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 flex items-center justify-center p-6">
      <div className="max-w-md w-full">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', duration: 0.5 }}
          className="w-24 h-24 mx-auto mb-6 bg-emerald-600 rounded-full flex items-center justify-center"
        >
          <Check className="w-12 h-12 text-white" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl shadow-xl p-8"
        >
          <h2 className="text-center mb-2">Order Confirmed!</h2>
          <p className="text-center text-gray-600 mb-6">
            Your order has been placed successfully
          </p>

          <div className="bg-emerald-50 rounded-2xl p-4 mb-6">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-gray-600">Order ID</span>
              <span className="text-sm">#{order.id}</span>
            </div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-gray-600">Items</span>
              <span className="text-sm">{order.items.length} items</span>
            </div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-gray-600">Total Amount</span>
              <span className="text-sm">₹{order.total.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Estimated Delivery</span>
              <span className="text-sm text-emerald-600">{order.eta}</span>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-2xl mb-6">
            <Package className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm">
                Your order is being prepared at <span className="font-medium">{order.darkStore}</span>
              </p>
            </div>
          </div>

          <Button
            onClick={onTrackOrder}
            className="w-full bg-emerald-600 hover:bg-emerald-700 py-6"
          >
            Track Your Order
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>

          <p className="text-center text-xs text-gray-500 mt-4">
            You will receive updates via SMS and in-app notifications
          </p>
        </motion.div>
      </div>
    </div>
  );
}
