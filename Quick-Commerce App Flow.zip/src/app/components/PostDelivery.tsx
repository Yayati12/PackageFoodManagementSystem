import { Star, IndianRupee, MessageCircle, RotateCcw, ThumbsUp } from 'lucide-react';
import { Order } from '../types';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { useState } from 'react';
import { motion } from 'motion/react';
import { toast } from 'sonner';

interface PostDeliveryProps {
  order: Order;
  onBackToHome: () => void;
}

export function PostDelivery({ order, onBackToHome }: PostDeliveryProps) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [tip, setTip] = useState(0);

  const tipOptions = [0, 10, 20, 30, 50];

  const handleSubmitRating = () => {
    if (rating === 0) {
      toast.error('Please select a rating');
      return;
    }
    toast.success('Thank you for your feedback!');
    setTimeout(() => onBackToHome(), 1500);
  };

  const handleReorder = () => {
    toast.success('Items added to cart!');
    setTimeout(() => onBackToHome(), 1000);
  };

  const handleReportIssue = () => {
    toast.success('Issue reported. Our team will contact you soon.');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-3xl mx-auto px-4 py-4">
          <h2>Rate Your Experience</h2>
          <p className="text-sm text-gray-600">Order ID: #{order.id}</p>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6">
        {/* Rating Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-4">
          <h3 className="text-center mb-4">How was your experience?</h3>
          <div className="flex justify-center gap-2 mb-6">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                onClick={() => setRating(star)}
                className="transition-transform hover:scale-110"
              >
                <Star
                  className={`w-12 h-12 ${
                    star <= (hoveredRating || rating)
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'text-gray-300'
                  }`}
                />
              </button>
            ))}
          </div>
          {rating > 0 && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <p className="text-center text-sm text-gray-600 mb-4">
                {rating === 5 && 'Excellent! 🎉'}
                {rating === 4 && 'Great! 😊'}
                {rating === 3 && 'Good 👍'}
                {rating === 2 && 'Could be better 😕'}
                {rating === 1 && 'We can do better 😞'}
              </p>
            </motion.div>
          )}

          <Textarea
            placeholder="Share your feedback (optional)"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            className="mb-4"
            rows={3}
          />

          <Button
            onClick={handleSubmitRating}
            className="w-full bg-emerald-600 hover:bg-emerald-700"
          >
            Submit Rating
          </Button>
        </div>

        {/* Tip Delivery Partner */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-4">
          <h4 className="mb-4 flex items-center gap-2">
            <ThumbsUp className="w-5 h-5 text-emerald-600" />
            Tip your delivery partner
          </h4>
          <p className="text-sm text-gray-600 mb-4">
            Show your appreciation to {order.deliveryPartner}
          </p>
          <div className="flex gap-2 mb-4">
            {tipOptions.map((amount) => (
              <button
                key={amount}
                onClick={() => setTip(amount)}
                className={`flex-1 py-3 rounded-xl border-2 transition-all ${
                  tip === amount
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-600'
                    : 'border-gray-200 hover:border-emerald-300'
                }`}
              >
                {amount === 0 ? 'No Tip' : `₹${amount}`}
              </button>
            ))}
          </div>
          {tip > 0 && (
            <Button variant="outline" className="w-full gap-2">
              <IndianRupee className="w-4 h-4" />
              Send ₹{tip} Tip
            </Button>
          )}
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <h4 className="mb-4">Quick Actions</h4>
          <div className="space-y-3">
            <Button
              onClick={handleReorder}
              variant="outline"
              className="w-full justify-start gap-3 py-6"
            >
              <RotateCcw className="w-5 h-5 text-emerald-600" />
              <div className="text-left">
                <p>Reorder Items</p>
                <p className="text-sm text-gray-600">Order the same items again</p>
              </div>
            </Button>

            <Button
              onClick={handleReportIssue}
              variant="outline"
              className="w-full justify-start gap-3 py-6"
            >
              <MessageCircle className="w-5 h-5 text-orange-600" />
              <div className="text-left">
                <p>Report an Issue</p>
                <p className="text-sm text-gray-600">Missing items, quality concerns, etc.</p>
              </div>
            </Button>
          </div>
        </div>

        <Button onClick={onBackToHome} variant="ghost" className="w-full mt-6">
          Back to Home
        </Button>
      </main>
    </div>
  );
}
