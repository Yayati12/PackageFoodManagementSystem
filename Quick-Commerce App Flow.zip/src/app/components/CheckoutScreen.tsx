import { ChevronLeft, MapPin, Zap, Clock, CreditCard, ChevronRight } from 'lucide-react';
import { Address } from '../types';
import { Button } from './ui/button';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { useState } from 'react';

interface CheckoutScreenProps {
  total: number;
  onPlaceOrder: (deliverySpeed: 'express' | 'standard', address: Address, paymentMethod: string) => void;
  onBack: () => void;
}

const mockAddresses: Address[] = [
  {
    id: '1',
    label: 'Home',
    street: '123 MG Road',
    area: 'Koramangala',
    city: 'Bangalore',
    pincode: '560034',
    isDefault: true,
  },
  {
    id: '2',
    label: 'Work',
    street: '456 Tech Park',
    area: 'Whitefield',
    city: 'Bangalore',
    pincode: '560066',
    isDefault: false,
  },
];

export function CheckoutScreen({ total, onPlaceOrder, onBack }: CheckoutScreenProps) {
  const [deliverySpeed, setDeliverySpeed] = useState<'express' | 'standard'>('express');
  const [selectedAddress, setSelectedAddress] = useState<Address>(mockAddresses[0]);
  const [paymentMethod, setPaymentMethod] = useState('upi');

  const deliveryOptions = [
    {
      id: 'express',
      name: 'Express Delivery',
      time: '10-15 mins',
      price: 0,
      icon: Zap,
    },
    {
      id: 'standard',
      name: 'Standard Delivery',
      time: '30-45 mins',
      price: 0,
      icon: Clock,
    },
  ];

  const paymentMethods = [
    { id: 'upi', name: 'UPI (PhonePe, GPay, Paytm)', icon: '💳' },
    { id: 'card', name: 'Credit/Debit Card', icon: '💳' },
    { id: 'cash', name: 'Cash on Delivery', icon: '💵' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-full">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2>Checkout</h2>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6 pb-32">
        {/* Delivery Speed */}
        <div className="bg-white rounded-2xl shadow-sm p-4 mb-4">
          <h4 className="mb-4">Select Delivery Speed</h4>
          <RadioGroup value={deliverySpeed} onValueChange={(value) => setDeliverySpeed(value as 'express' | 'standard')}>
            {deliveryOptions.map((option) => (
              <div
                key={option.id}
                className={`flex items-center justify-between p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  deliverySpeed === option.id
                    ? 'border-emerald-600 bg-emerald-50'
                    : 'border-gray-200 hover:border-emerald-300'
                }`}
                onClick={() => setDeliverySpeed(option.id as 'express' | 'standard')}
              >
                <div className="flex items-center gap-3">
                  <RadioGroupItem value={option.id} id={option.id} />
                  <option.icon className={`w-5 h-5 ${deliverySpeed === option.id ? 'text-emerald-600' : 'text-gray-400'}`} />
                  <div>
                    <Label htmlFor={option.id} className="cursor-pointer">
                      {option.name}
                    </Label>
                    <p className="text-sm text-gray-600">{option.time}</p>
                  </div>
                </div>
                {option.price === 0 ? (
                  <span className="text-sm text-green-600">FREE</span>
                ) : (
                  <span className="text-sm">₹{option.price}</span>
                )}
              </div>
            ))}
          </RadioGroup>
        </div>

        {/* Delivery Address */}
        <div className="bg-white rounded-2xl shadow-sm p-4 mb-4">
          <h4 className="mb-4 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-600" />
            Delivery Address
          </h4>
          <RadioGroup value={selectedAddress.id} onValueChange={(value) => setSelectedAddress(mockAddresses.find(a => a.id === value)!)}>
            {mockAddresses.map((address) => (
              <div
                key={address.id}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  selectedAddress.id === address.id
                    ? 'border-emerald-600 bg-emerald-50'
                    : 'border-gray-200 hover:border-emerald-300'
                }`}
                onClick={() => setSelectedAddress(address)}
              >
                <div className="flex items-start gap-3">
                  <RadioGroupItem value={address.id} id={address.id} className="mt-1" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Label htmlFor={address.id} className="cursor-pointer">
                        {address.label}
                      </Label>
                      {address.isDefault && (
                        <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded">
                          Default
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">
                      {address.street}, {address.area}, {address.city} - {address.pincode}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </RadioGroup>
          <Button variant="outline" className="w-full mt-3">
            + Add New Address
          </Button>
        </div>

        {/* Payment Method */}
        <div className="bg-white rounded-2xl shadow-sm p-4">
          <h4 className="mb-4 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-emerald-600" />
            Payment Method
          </h4>
          <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
            {paymentMethods.map((method) => (
              <div
                key={method.id}
                className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  paymentMethod === method.id
                    ? 'border-emerald-600 bg-emerald-50'
                    : 'border-gray-200 hover:border-emerald-300'
                }`}
                onClick={() => setPaymentMethod(method.id)}
              >
                <RadioGroupItem value={method.id} id={method.id} />
                <span className="text-xl">{method.icon}</span>
                <Label htmlFor={method.id} className="cursor-pointer flex-1">
                  {method.name}
                </Label>
              </div>
            ))}
          </RadioGroup>
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-800">
              🔒 All transactions are secure and encrypted
            </p>
          </div>
        </div>
      </main>

      {/* Bottom Place Order Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Total Amount</p>
            <p>₹{total.toFixed(2)}</p>
          </div>
          <Button
            onClick={() => onPlaceOrder(deliverySpeed, selectedAddress, paymentMethod)}
            className="bg-emerald-600 hover:bg-emerald-700 px-8 py-6"
          >
            Place Order
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
