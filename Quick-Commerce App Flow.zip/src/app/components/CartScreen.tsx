import { X, Plus, Minus, Tag, ChevronRight, ShoppingCart } from 'lucide-react';
import { CartItem, Coupon } from '../types';
import { coupons } from '../data/products';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { useState } from 'react';

interface CartScreenProps {
  cart: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveFromCart: (productId: string) => void;
  onProceedToCheckout: (discount: number) => void;
  onBack: () => void;
}

export function CartScreen({
  cart,
  onUpdateQuantity,
  onRemoveFromCart,
  onProceedToCheckout,
  onBack,
}: CartScreenProps) {
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState('');

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = appliedCoupon ? appliedCoupon.discount : 0;
  const deliveryFee = subtotal > 199 ? 0 : 29;
  const total = subtotal - discount + deliveryFee;

  const handleApplyCoupon = () => {
    const coupon = coupons.find((c) => c.code.toLowerCase() === couponCode.toLowerCase());
    if (!coupon) {
      setCouponError('Invalid coupon code');
      return;
    }
    if (subtotal < coupon.minOrder) {
      setCouponError(`Minimum order of ₹${coupon.minOrder} required`);
      return;
    }
    setAppliedCoupon(coupon);
    setCouponError('');
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
        <div className="text-center">
          <ShoppingCart className="w-24 h-24 text-gray-300 mx-auto mb-4" />
          <h2 className="mb-2">Your cart is empty</h2>
          <p className="text-gray-600 mb-6">Add some fresh items to get started!</p>
          <Button onClick={onBack} className="bg-emerald-600 hover:bg-emerald-700">
            Start Shopping
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-6 h-6" />
          </button>
          <h2>My Cart ({cart.length} items)</h2>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6 pb-32">
        {/* Cart Items */}
        <div className="bg-white rounded-2xl shadow-sm p-4 mb-4">
          {cart.map((item) => (
            <div key={item.id} className="flex gap-4 py-4 border-b last:border-b-0">
              <img
                src={item.image}
                alt={item.name}
                className="w-20 h-20 rounded-xl object-cover"
              />
              <div className="flex-1">
                <h4 className="mb-1">{item.name}</h4>
                <p className="text-sm text-gray-600 mb-2">{item.unit}</p>
                <div className="flex items-center justify-between">
                  <span>₹{item.price}</span>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() =>
                        item.quantity === 1
                          ? onRemoveFromCart(item.id)
                          : onUpdateQuantity(item.id, item.quantity - 1)
                      }
                      className="w-8 h-8 rounded-full border-2 border-emerald-600 text-emerald-600 flex items-center justify-center hover:bg-emerald-50"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span>{item.quantity}</span>
                    <button
                      onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                      className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center hover:bg-emerald-700"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Coupon Section */}
        <div className="bg-white rounded-2xl shadow-sm p-4 mb-4">
          <h4 className="mb-3 flex items-center gap-2">
            <Tag className="w-5 h-5 text-emerald-600" />
            Apply Coupon
          </h4>
          <div className="flex gap-2 mb-4">
            <Input
              type="text"
              placeholder="Enter coupon code"
              value={couponCode}
              onChange={(e) => {
                setCouponCode(e.target.value);
                setCouponError('');
              }}
              className="flex-1"
            />
            <Button onClick={handleApplyCoupon} variant="outline">
              Apply
            </Button>
          </div>
          {couponError && <p className="text-sm text-red-600 mb-3">{couponError}</p>}
          {appliedCoupon && (
            <Badge className="bg-green-100 text-green-800">
              {appliedCoupon.code} applied - ₹{appliedCoupon.discount} off
            </Badge>
          )}
          
          <div className="mt-4 space-y-2">
            {coupons.map((coupon) => (
              <button
                key={coupon.code}
                onClick={() => {
                  setCouponCode(coupon.code);
                  setCouponError('');
                }}
                className="w-full flex items-center justify-between p-3 border border-dashed border-emerald-600 rounded-lg hover:bg-emerald-50 transition-colors"
              >
                <div className="text-left">
                  <p className="text-sm text-emerald-600">{coupon.code}</p>
                  <p className="text-xs text-gray-600">{coupon.description}</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            ))}
          </div>
        </div>

        {/* Bill Details */}
        <div className="bg-white rounded-2xl shadow-sm p-4">
          <h4 className="mb-4">Bill Details</h4>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Subtotal</span>
              <span>₹{subtotal.toFixed(2)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-sm text-green-600">
                <span>Coupon Discount</span>
                <span>-₹{discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Delivery Fee</span>
              <span>{deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}</span>
            </div>
            {subtotal < 199 && (
              <p className="text-xs text-gray-600 bg-blue-50 p-2 rounded">
                Add items worth ₹{(199 - subtotal).toFixed(2)} more for FREE delivery
              </p>
            )}
            <div className="flex justify-between pt-3 border-t">
              <span>Total</span>
              <span>₹{total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Checkout Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Total Amount</p>
            <p>₹{total.toFixed(2)}</p>
          </div>
          <Button
            onClick={() => onProceedToCheckout(discount)}
            className="bg-emerald-600 hover:bg-emerald-700 px-8 py-6"
          >
            Proceed to Checkout
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
