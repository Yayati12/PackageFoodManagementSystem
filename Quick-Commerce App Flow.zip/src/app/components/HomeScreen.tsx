import { Search, ShoppingCart, MapPin, Star, Plus, LayoutGrid } from 'lucide-react';
import { Product } from '../types';
import { categories, products } from '../data/products';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { useState } from 'react';

interface HomeScreenProps {
  location: string;
  cart: Product[];
  onAddToCart: (product: Product) => void;
  onViewCart: () => void;
}

export function HomeScreen({ location, cart, onAddToCart, onViewCart }: HomeScreenProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = products.filter((product) => {
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    const matchesSearch =
      searchQuery === '' ||
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-emerald-600">AlwayzzzFresh</h1>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="w-4 h-4" />
                <span>{location}</span>
              </div>
            </div>
            <button
              onClick={onViewCart}
              className="relative p-3 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ShoppingCart className="w-6 h-6" />
              {cart.length > 0 && (
                <Badge className="absolute -top-1 -right-1 w-6 h-6 flex items-center justify-center rounded-full bg-emerald-600">
                  {cart.length}
                </Badge>
              )}
            </button>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Search for products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 py-6"
            />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Categories */}
        <div className="mb-6">
          <h3 className="mb-4 flex items-center gap-2">
            <LayoutGrid className="w-5 h-5" />
            Browse Categories
          </h3>
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`flex-shrink-0 px-6 py-3 rounded-full border-2 transition-all ${
                selectedCategory === 'all'
                  ? 'bg-emerald-600 text-white border-emerald-600'
                  : 'bg-white border-gray-200 hover:border-emerald-600'
              }`}
            >
              <span>All Items</span>
            </button>
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`flex-shrink-0 px-6 py-3 rounded-full border-2 transition-all ${
                  selectedCategory === category.id
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-white border-gray-200 hover:border-emerald-600'
                }`}
              >
                <span className="mr-2">{category.icon}</span>
                <span>{category.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3>{selectedCategory === 'all' ? 'All Products' : categories.find(c => c.id === selectedCategory)?.name}</h3>
            <span className="text-sm text-gray-600">{filteredProducts.length} items</span>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow overflow-hidden"
              >
                <div className="relative aspect-square">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  {product.discount && (
                    <Badge className="absolute top-3 left-3 bg-red-500 text-white">
                      {product.discount}% OFF
                    </Badge>
                  )}
                </div>
                
                <div className="p-4">
                  <h4 className="mb-1">{product.name}</h4>
                  <p className="text-sm text-gray-600 mb-2">{product.unit}</p>
                  
                  <div className="flex items-center gap-1 mb-3">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm">{product.rating}</span>
                    <span className="text-sm text-gray-400 mx-2">•</span>
                    <span className="text-sm text-emerald-600">{product.deliveryTime}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-baseline gap-2">
                        <span>₹{product.price}</span>
                        {product.originalPrice && (
                          <span className="text-sm text-gray-400 line-through">
                            ₹{product.originalPrice}
                          </span>
                        )}
                      </div>
                    </div>
                    <Button
                      onClick={() => onAddToCart(product)}
                      size="sm"
                      className="bg-emerald-600 hover:bg-emerald-700"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
