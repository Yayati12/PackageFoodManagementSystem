import { Check, Receipt, Leaf } from 'lucide-react';
import { Order } from '../types';
import { Button } from './ui/button';
import { motion } from 'motion/react';

interface DeliveryCompleteProps {
  order: Order;
  onContinue: () => void;
}

export function DeliveryComplete({ order, onContinue }: DeliveryCompleteProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 flex items-center justify-center p-6">
      <div className="max-w-md w-full">
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', duration: 0.6 }}
          className="w-24 h-24 mx-auto mb-6 bg-emerald-600 rounded-full flex items-center justify-center"
        >
          <Check className="w-12 h-12 text-white" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl shadow-xl p-8"
        >
          <h2 className="text-center mb-2">Delivered Successfully!</h2>
          <p className="text-center text-gray-600 mb-6">
            Your order has been delivered. Enjoy your fresh items!
          </p>

          <div className="bg-emerald-50 rounded-2xl p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <Receipt className="w-6 h-6 text-emerald-600" />
              <h4>Digital Invoice</h4>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Order ID</span>
                <span>#{order.id}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Items</span>
                <span>{order.items.length} items</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Delivery Partner</span>
                <span>{order.deliveryPartner}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Delivery Type</span>
                <span className="capitalize">{order.deliverySpeed}</span>
              </div>
              <div className="h-px bg-emerald-200 my-3" />
              <div className="flex justify-between">
                <span>Total Paid</span>
                <span className="text-emerald-600">₹{order.total.toFixed(2)}</span>
              </div>
            </div>
            <Button variant="outline" className="w-full mt-4">
              Download Invoice
            </Button>
          </div>

          <div className="flex items-start gap-3 p-4 bg-green-50 rounded-2xl mb-6">
            <Leaf className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-green-800">
                Your order was delivered in eco-friendly packaging. Thank you for choosing sustainable delivery!
              </p>
            </div>
          </div>

          <Button
            onClick={onContinue}
            className="w-full bg-emerald-600 hover:bg-emerald-700 py-6"
          >
            Continue
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
