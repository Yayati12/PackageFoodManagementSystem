import { MapPin, Navigation } from 'lucide-react';
import { Button } from './ui/button';

interface LocationPermissionProps {
  onLocationGranted: (location: string) => void;
}

export function LocationPermission({ onLocationGranted }: LocationPermissionProps) {
  const handleAllowLocation = () => {
    // Simulate location permission
    setTimeout(() => {
      onLocationGranted('Koramangala, Bangalore');
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 text-center">
        <div className="mb-6">
          <div className="w-20 h-20 mx-auto bg-emerald-100 rounded-full flex items-center justify-center mb-4">
            <MapPin className="w-10 h-10 text-emerald-600" />
          </div>
          <h1 className="text-emerald-600 mb-2">AlwayzzzFresh</h1>
          <h2 className="mb-2">Enable Location Access</h2>
          <p className="text-gray-600">
            We need your location to show nearby stores and provide accurate delivery times
          </p>
        </div>

        <div className="space-y-4 mb-6">
          <div className="flex items-start gap-3 text-left">
            <Navigation className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm">Find the nearest dark store for fastest delivery</p>
            </div>
          </div>
          <div className="flex items-start gap-3 text-left">
            <MapPin className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm">Get accurate delivery estimates based on your area</p>
            </div>
          </div>
        </div>

        <Button
          onClick={handleAllowLocation}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-6"
        >
          Allow Location Access
        </Button>
        
        <button
          onClick={() => onLocationGranted('Default Location')}
          className="mt-4 text-sm text-gray-500 hover:text-gray-700"
        >
          Skip for now
        </button>
      </div>
    </div>
  );
}
