import { ArrowLeft, ShoppingCart, Star } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { products } from '../data/products';
import { Product } from '../types';

interface ProductListingProps {
  category: string;
  onBack: () => void;
  onProductSelect: (product: Product) => void;
  onCartClick: () => void;
  cartItemCount: number;
}

export function ProductListing({
  category,
  onBack,
  onProductSelect,
  onCartClick,
  cartItemCount,
}: ProductListingProps) {
  const categoryProducts = products.filter((p) => p.category === category);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white sticky top-0 z-10 shadow-sm">
        <div className="max-w-md mx-auto p-4 flex items-center gap-4">
          <button onClick={onBack}>
            <ArrowLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="flex-1 text-gray-900">{category}</h1>
          <button onClick={onCartClick} className="relative">
            <ShoppingCart className="w-6 h-6 text-gray-700" />
            {cartItemCount > 0 && (
              <Badge className="absolute -top-2 -right-2 bg-red-500 text-white px-1.5 py-0.5 text-xs">
                {cartItemCount}
              </Badge>
            )}
          </button>
        </div>
      </div>

      {/* Products Grid */}
      <div className="max-w-md mx-auto p-4">
        <p className="text-sm text-gray-600 mb-4">
          {categoryProducts.length} items available
        </p>
        <div className="grid grid-cols-2 gap-4">
          {categoryProducts.map((product) => (
            <button
              key={product.id}
              onClick={() => onProductSelect(product)}
              className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-gray-100 text-left"
            >
              <div className="relative aspect-square">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                {product.discount && (
                  <Badge className="absolute top-2 right-2 bg-red-500 text-white">
                    {product.discount}% OFF
                  </Badge>
                )}
              </div>
              <div className="p-3 space-y-2">
                <p className="text-sm text-gray-900 line-clamp-2">{product.name}</p>
                <p className="text-xs text-gray-500">{product.unit}</p>
                <div className="flex items-center gap-1 text-xs text-gray-600">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  <span>{product.rating}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-green-600">${product.price}</span>
                  {product.originalPrice && (
                    <span className="text-xs text-gray-400 line-through">
                      ${product.originalPrice}
                    </span>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
