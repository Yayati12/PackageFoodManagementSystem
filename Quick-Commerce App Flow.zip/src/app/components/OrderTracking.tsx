import { MapPin, Package, Truck, Check, Clock, Navigation, Phone } from 'lucide-react';
import { Order } from '../types';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { useEffect, useState } from 'react';
import { motion } from 'motion/react';

interface OrderTrackingProps {
  order: Order;
  onOrderDelivered: () => void;
}

const statusSteps = [
  { id: 'confirmed', label: 'Order Confirmed', icon: Check },
  { id: 'picking', label: 'Picking Items', icon: Package },
  { id: 'packed', label: 'Quality Check & Packed', icon: Check },
  { id: 'out-for-delivery', label: 'Out for Delivery', icon: Truck },
  { id: 'delivered', label: 'Delivered', icon: Check },
];

export function OrderTracking({ order, onOrderDelivered }: OrderTrackingProps) {
  const [currentStatus, setCurrentStatus] = useState<Order['status']>(order.status);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Simulate order progress
    const statusOrder: Order['status'][] = ['confirmed', 'picking', 'packed', 'out-for-delivery', 'delivered'];
    let currentIndex = statusOrder.indexOf(currentStatus);

    const interval = setInterval(() => {
      if (currentIndex < statusOrder.length - 1) {
        currentIndex++;
        setCurrentStatus(statusOrder[currentIndex]);
        setProgress((currentIndex / (statusOrder.length - 1)) * 100);
      } else {
        clearInterval(interval);
        setTimeout(() => onOrderDelivered(), 2000);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [currentStatus, onOrderDelivered]);

  const currentStepIndex = statusSteps.findIndex((step) => step.id === currentStatus);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-3xl mx-auto px-4 py-4">
          <h2 className="mb-2">Track Order</h2>
          <p className="text-sm text-gray-600">Order ID: #{order.id}</p>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6">
        {/* Live Map Placeholder */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden mb-4">
          <div className="aspect-video bg-gradient-to-br from-emerald-100 to-blue-100 relative flex items-center justify-center">
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
              >
                <Navigation className="w-12 h-12 text-emerald-600" />
              </motion.div>
            </div>
            <div className="absolute top-4 left-4 bg-white px-4 py-2 rounded-full shadow-md">
              <p className="text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-600" />
                <span>ETA: {order.eta}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Status Progress */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-4">
          <h3 className="mb-6">Order Status</h3>
          <div className="space-y-6">
            {statusSteps.map((step, index) => {
              const StepIcon = step.icon;
              const isCompleted = index <= currentStepIndex;
              const isCurrent = index === currentStepIndex;

              return (
                <div key={step.id} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: isCompleted ? 1 : 0.8 }}
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        isCompleted
                          ? 'bg-emerald-600 text-white'
                          : 'bg-gray-200 text-gray-400'
                      }`}
                    >
                      <StepIcon className="w-5 h-5" />
                    </motion.div>
                    {index < statusSteps.length - 1 && (
                      <div
                        className={`w-0.5 h-12 mt-2 ${
                          isCompleted ? 'bg-emerald-600' : 'bg-gray-200'
                        }`}
                      />
                    )}
                  </div>
                  <div className="flex-1 pb-8">
                    <h4 className={isCurrent ? 'text-emerald-600' : ''}>{step.label}</h4>
                    {isCurrent && (
                      <motion.p
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-sm text-gray-600 mt-1"
                      >
                        {currentStatus === 'confirmed' && 'Your order has been confirmed and assigned to a dark store'}
                        {currentStatus === 'picking' && 'Our picker is collecting your items with care'}
                        {currentStatus === 'packed' && 'Items packed in eco-friendly bags after quality check'}
                        {currentStatus === 'out-for-delivery' && `${order.deliveryPartner} is on the way to your location`}
                      </motion.p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Delivery Partner Info */}
        {currentStatus === 'out-for-delivery' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-sm p-4 mb-4"
          >
            <h4 className="mb-4">Delivery Partner</h4>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center">
                <span className="text-xl">🚴</span>
              </div>
              <div className="flex-1">
                <p>{order.deliveryPartner}</p>
                <p className="text-sm text-gray-600">On the fastest route</p>
              </div>
              <Button variant="outline" size="sm" className="gap-2">
                <Phone className="w-4 h-4" />
                Call
              </Button>
            </div>
          </motion.div>
        )}

        {/* Delivery Address */}
        <div className="bg-white rounded-2xl shadow-sm p-4">
          <h4 className="mb-3 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-600" />
            Delivery Address
          </h4>
          <p className="text-sm text-gray-600">
            {order.address.street}, {order.address.area}, {order.address.city} - {order.address.pincode}
          </p>
        </div>
      </main>
    </div>
  );
}
