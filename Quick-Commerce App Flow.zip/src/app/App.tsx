import { useState } from 'react';
import { Toaster } from './components/ui/sonner';
import { Login } from './components/Login';
import { Register } from './components/Register';
import { ForgotPassword } from './components/ForgotPassword';
import { LocationPermission } from './components/LocationPermission';
import { HomeScreen } from './components/HomeScreen';
import { CartScreen } from './components/CartScreen';
import { CheckoutScreen } from './components/CheckoutScreen';
import { OrderConfirmation } from './components/OrderConfirmation';
import { OrderTracking } from './components/OrderTracking';
import { DeliveryComplete } from './components/DeliveryComplete';
import { PostDelivery } from './components/PostDelivery';
import { Product, CartItem, Order, Screen, Address, User } from './types';

export default function App() {
  const [screen, setScreen] = useState<Screen>('login');
  const [user, setUser] = useState<User | null>(null);
  const [location, setLocation] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [appliedDiscount, setAppliedDiscount] = useState(0);

  const handleLogin = (email: string, password: string) => {
    // Mock login - in real app this would authenticate with backend
    const mockUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: email.split('@')[0],
      email: email,
      phone: '9876543210',
    };
    setUser(mockUser);
    setScreen('location');
  };

  const handleRegister = (name: string, email: string, phone: string, password: string) => {
    // Mock registration - in real app this would create account in backend
    const mockUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: name,
      email: email,
      phone: phone,
    };
    setUser(mockUser);
    setScreen('location');
  };

  const handleLocationGranted = (loc: string) => {
    setLocation(loc);
    setScreen('home');
  };

  const handleAddToCart = (product: Product) => {
    const existingItem = cart.find((item) => item.id === product.id);
    if (existingItem) {
      setCart(
        cart.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        )
      );
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    setCart(
      cart.map((item) =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(cart.filter((item) => item.id !== productId));
  };

  const handleProceedToCheckout = (discount: number) => {
    setAppliedDiscount(discount);
    setScreen('checkout');
  };

  const handlePlaceOrder = (
    deliverySpeed: 'express' | 'standard',
    address: Address,
    paymentMethod: string
  ) => {
    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const deliveryFee = subtotal > 199 ? 0 : 29;
    const total = subtotal - appliedDiscount + deliveryFee;

    const newOrder: Order = {
      id: Math.random().toString(36).substr(2, 9).toUpperCase(),
      items: cart,
      total,
      deliverySpeed,
      address,
      paymentMethod,
      status: 'confirmed',
      timestamp: new Date(),
      eta: deliverySpeed === 'express' ? '10-15 mins' : '30-45 mins',
      darkStore: 'AlwayzzzFresh Hub - Koramangala',
      deliveryPartner: 'Rajesh Kumar',
    };

    setCurrentOrder(newOrder);
    setCart([]);
    setScreen('confirmation');
  };

  const handleBackToHome = () => {
    setScreen('home');
    setCurrentOrder(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {screen === 'login' && (
        <Login 
          onLogin={handleLogin} 
          onNavigateToRegister={() => setScreen('register')}
          onNavigateToForgotPassword={() => setScreen('forgot-password')}
        />
      )}

      {screen === 'register' && (
        <Register 
          onRegister={handleRegister} 
          onNavigateToLogin={() => setScreen('login')} 
        />
      )}

      {screen === 'forgot-password' && (
        <ForgotPassword onNavigateToLogin={() => setScreen('login')} />
      )}

      {screen === 'location' && (
        <LocationPermission onLocationGranted={handleLocationGranted} />
      )}

      {screen === 'home' && (
        <HomeScreen
          location={location}
          cart={cart}
          onAddToCart={handleAddToCart}
          onViewCart={() => setScreen('cart')}
        />
      )}

      {screen === 'cart' && (
        <CartScreen
          cart={cart}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveFromCart={handleRemoveFromCart}
          onProceedToCheckout={handleProceedToCheckout}
          onBack={() => setScreen('home')}
        />
      )}

      {screen === 'checkout' && (
        <CheckoutScreen
          total={
            cart.reduce((sum, item) => sum + item.price * item.quantity, 0) -
            appliedDiscount +
            (cart.reduce((sum, item) => sum + item.price * item.quantity, 0) > 199 ? 0 : 29)
          }
          onPlaceOrder={handlePlaceOrder}
          onBack={() => setScreen('cart')}
        />
      )}

      {screen === 'confirmation' && currentOrder && (
        <OrderConfirmation
          order={currentOrder}
          onTrackOrder={() => setScreen('tracking')}
        />
      )}

      {screen === 'tracking' && currentOrder && (
        <OrderTracking
          order={currentOrder}
          onOrderDelivered={() => setScreen('delivered')}
        />
      )}

      {screen === 'delivered' && currentOrder && (
        <DeliveryComplete
          order={currentOrder}
          onContinue={() => setScreen('post-delivery')}
        />
      )}

      {screen === 'post-delivery' && currentOrder && (
        <PostDelivery order={currentOrder} onBackToHome={handleBackToHome} />
      )}

      <Toaster />
    </div>
  );
}