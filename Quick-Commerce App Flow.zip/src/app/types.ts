export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  image: string;
  category: string;
  unit: string;
  inStock: boolean;
  rating: number;
  deliveryTime: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Address {
  id: string;
  label: string;
  street: string;
  area: string;
  city: string;
  pincode: string;
  isDefault: boolean;
}

export interface Coupon {
  code: string;
  description: string;
  discount: number;
  minOrder: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  deliverySpeed: 'express' | 'standard';
  address: Address;
  paymentMethod: string;
  status: 'confirmed' | 'picking' | 'packed' | 'out-for-delivery' | 'delivered';
  timestamp: Date;
  eta: string;
  darkStore: string;
  deliveryPartner: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
}

export type Screen =
  | 'login'
  | 'register'
  | 'forgot-password'
  | 'location'
  | 'home'
  | 'product'
  | 'cart'
  | 'checkout'
  | 'confirmation'
  | 'tracking'
  | 'delivered'
  | 'post-delivery';